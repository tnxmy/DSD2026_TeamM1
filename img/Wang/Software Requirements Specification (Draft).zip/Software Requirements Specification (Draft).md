# Software Requirements Specification (Draft)

Revision History:

| Date | Author | Description |
| ---- | ------ | ----------- |
| Apr 5 | Xiaoquan Xu | Add use cases |

## 0. Background

Why do we need this document and who will use it.

## 1. Use Cases

1.1. Case: User Register 注册
1.2. Case: User Login 登录

## 2. Key Examples

### 2.1. User Register

#### 2.1.1. Basic info

- Reference to Use Case 1.1.
- Version: 0.1
- Created: 
- Authors: 
- Source: 
- Actors: 
- Goal: 
- Summary: 
- Trigger: 
- Frequency: 
- Precondition: 
- Postconditions: 

![]()

#### 2.1.2. Basic Flow

| Actor | System |
| ----- | ------ |
|  |  |
|  |  |
|  |  |
|  |  |
|  |  |
|  |  |

#### 2.1.3. Alternative Flow

| Actor | System |
| ----- | ------ |
|  |  |
|  |  |
|  |  |
|  |  |
|  |  |
|  |  |

### 2.2. Sensor Connection

#### 2.2.1. Basic Info

- Reference to Use Case ...
- Version: 1

- Created: Apr 1
- Authors: Wenhui ZHOU
- Source: Server
- Actors: Add a user to the system
- Goal: To make user register in the system
- Summary: This requirement allows new user to join the system and use the system to upload motion data and predict motion.
- Trigger: When new users want to join in the system
- Frequency: Decided by number of new users
- Precondition: The system permit adding new user
- Postconditions: The interface has verified the two inputs of password are the same

![](https://doc.ciel.pro/uploads/330b3aef93b0cd2a1c8ba5401.png)

#### Basic Flow

| Actor | System |
| ----- | ------ |
| New User registers in system |  |
|  | Check the user account is unique |
|  | Check the password is consistent with the regulation |
|  | Create user account and add to the database |
|  | Return success information to the Interface |
| Interface show success information |  |

#### Alternative Flow

| Actor | System |
| ----- | ------ |
| User account has existed |  |
|  | Return information of user account repetition |
| User password is not consistent with regulation |  |
|  | Return information of password format error |

